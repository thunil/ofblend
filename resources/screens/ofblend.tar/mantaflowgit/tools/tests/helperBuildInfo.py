# Print build info

from manta import *

# note - executable should print by default, for safety, print again...
printBuildInfo()

